#! /usr/bin/env python
#coding=utf8
#   2011-09-27 Lawrence Oliver Sunglao <lawrence.sunglao@remotestaff.com.au>
#   -   version update
#   2010-01-03 Lawrence Oliver Sunglao <lawrence.sunglao@remotestaff.com.au>
#   -   packaged for Mac OS X

import settings

import wx
from Staff import Staff
from RsscGuiWx import MainFrame

from twisted.internet import reactor

if __name__ == "__main__":
    staff = Staff()
    app = wx.App()
    app.RestoreStdio()
    reactor.registerWxApp(app)
    wx.InitAllImageHandlers()
    MainFrame = MainFrame(None, -1, "")

    MainFrame.textCtrlServer.SetValue(settings.SERVER_NAME)
    MainFrame.textCtrlVersion.SetValue(settings.RSSC_VERSION)
    MainFrame.spinCtrlPort.SetValue(settings.SERVER_PORT)

    staff.SetGui(MainFrame)
    MainFrame.SetStaff(staff)
    app.SetTopWindow(MainFrame)
    MainFrame.Show()
    reactor.run()
